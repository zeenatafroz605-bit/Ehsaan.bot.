from flask import Flask, request, jsonify, render_template_string
from groq import Groq

# ================= API =================
client = Groq(
    api_key="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"
)

app = Flask(__name__)
chat_memory = []

MAKER_QUESTIONS = [
    "who is your maker",
    "who made you",
    "who created you",
    "tumhara maker kaun hai"
]

# ================= HTML =================
HTML = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>EHSAAN.BOT</title>

<style>
*{box-sizing:border-box}
body{
  margin:0;
  background:#0f1724;
  color:white;
  font-family:system-ui;
}
header{
  padding:12px;
  text-align:center;
  background:#020617;
  font-weight:bold;
}
#chat{
  height:78vh;
  overflow-y:auto;
  padding:12px;
}
.bubble{
  max-width:85%;
  padding:10px;
  margin:8px 0;
  border-radius:12px;
  line-height:1.4;
  word-wrap:break-word;
}
.user{
  background:#2563eb;
  margin-left:auto;
}
.bot{
  background:#020617;
  border:1px solid #1e293b;
}
pre{
  background:#000;
  padding:10px;
  border-radius:8px;
  overflow-x:auto;
}
#inputBar{
  position:fixed;
  bottom:0;
  width:100%;
  background:#020617;
  padding:8px;
  display:flex;
  gap:6px;
}
input{
  flex:1;
  padding:10px;
  font-size:16px;
  border-radius:8px;
  border:none;
}
button{
  padding:10px;
  border:none;
  border-radius:8px;
  font-size:18px;
}
#mic{background:#ef4444;color:white}
#send{background:#22c55e;color:white}
#controls{
  display:flex;
  gap:8px;
  padding:6px;
  background:#020617;
}
</style>
</head>

<body>

<header>🤖 EHSAAN.BOT</header>

<div id="chat"></div>

<div id="controls">
<label>🔊</label>
<input type="range" id="volume" min="0" max="1" step="0.1" value="1">
<select id="voiceType">
<option value="female">Female</option>
<option value="male">Male</option>
</select>
</div>

<div id="inputBar">
<button id="mic" onclick="micControl()">🎤</button>
<input id="msg" placeholder="Type or speak..." />
<button id="send" onclick="send()">➤</button>
</div>

<script>
let micState = 0;
let recognition;
let synth = window.speechSynthesis;

if ('webkitSpeechRecognition' in window) {
  recognition = new webkitSpeechRecognition();
  recognition.continuous = true;
  recognition.onresult = e => {
    document.getElementById("msg").value =
    e.results[e.results.length-1][0].transcript;
  };
}

function micControl(){
  let mic=document.getElementById("mic");
  if(micState===0){
    recognition.start();
    mic.innerText="🔴";
    micState=1;
  }else if(micState===1){
    recognition.stop();
    mic.innerText="🔇";
    micState=2;
  }else{
    synth.cancel();
    mic.innerText="🎤";
    micState=0;
  }
}

function detectLang(t){
  return /[\\u0900-\\u097F]/.test(t) ? "hi-IN" : "en-IN";
}

function speak(text){
  synth.cancel();
  let u=new SpeechSynthesisUtterance(text);
  u.lang=detectLang(text);
  u.volume=document.getElementById("volume").value;
  synth.speak(u);
}

async function send(){
  let chat=document.getElementById("chat");
  let msg=document.getElementById("msg").value;
  if(!msg) return;

  synth.cancel();
  chat.innerHTML+=`<div class="bubble user">${msg}</div>`;
  document.getElementById("msg").value="";

  let r=await fetch("/chat",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({message:msg})
  });
  let j=await r.json();

  chat.innerHTML+=`<div class="bubble bot">${j.reply}</div>`;
  chat.scrollTop=chat.scrollHeight;
  speak(j.reply.replace(/<[^>]*>/g,""));
}
</script>

</body>
</html>
"""

# ================= ROUTES =================
@app.route("/")
def home():
    return render_template_string(HTML)

@app.route("/chat", methods=["POST"])
def chat():
    user = request.json["message"].lower()

    for q in MAKER_QUESTIONS:
        if q in user:
            return jsonify({"reply":"Ehsaan is my maker."})

    chat_memory.append({"role":"user","content":user})
    chat_memory[:] = chat_memory[-6:]

    res = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role":"system","content":"You are EHSAAN.BOT. Your maker is Ehsaan."}]+chat_memory
    )

    reply = res.choices[0].message.content

    # 🔥 FORMAT FIX
    reply = reply.replace("```", "<pre><code>").replace("\n", "<br>")

    chat_memory.append({"role":"assistant","content":reply})
    return jsonify({"reply":reply})
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
